define(['jquery'], function($){
    var CustomWidget = function () {
    	var self = this;
    	var checkDealPage = null;
		this.callbacks = {
			render: function(){
				console.log('render');
				let w_code = self.get_settings().widget_code;

				var render_data ='<div class="nw_form">'+
						       		'<div id="w_logo">'+
						       			'<img src="/upl/{{w_code}}/widget/images/logo.png" id="firstwidget_image"></img>'+
						       		'</div>'+
						       		'<div id="js-sub-lists-container">'+
						       		'</div>'+
						           '<div id="js-sub-subs-container">'+
						           '</div>'+
						           '<a href="#openModal">{{btn_text}}</button></div>'+
						       '<div class="already-subs"></div>'+
						       '<link type="text/css" rel="stylesheet" href="/upl/{{w_code}}/widget/style.css" >'+
						       '<div id="modal-region"></div>';

				self.render_template({
					caption:{
						class_name:'goodwilltestwidget',
					},
					body: "",
					render : render_data 
				}, {
					name:"goodwilltestwidget",
     				w_code: w_code,
     				btn_text:"Открыть модальное окно"
				});

				$('#modal-region').load('/upl/' + w_code + '/widget/modal-template.html');

				return true;
			},
			init: function(){
				console.log('init');
				return true;
			},
			bind_actions: function(){
				console.log('bind_actions');
				return true;
			},
			settings: function(){
				return true;
			},
			onSave: function(){
				return true;
			},
			destroy: function(){
				console.log('destroy');
			},
			contacts: {
					//select contacts in list and clicked on widget name
					selected: function(){
						console.log('contacts');
					}
				},
			leads: {
					//select leads in list and clicked on widget name
					selected: function(){
						console.log('leads');
					}
				},
			tasks: {
					//select taks in list and clicked on widget name
					selected: function(){
						console.log('tasks');
					}
				}
		};
		return this;
    };

return CustomWidget;
});